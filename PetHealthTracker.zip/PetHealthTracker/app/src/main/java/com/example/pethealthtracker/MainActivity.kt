package com.example.pethealthtracker

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    private lateinit var petNameInput: EditText
    private lateinit var breedInput: EditText
    private lateinit var petAgeInput: EditText
    private lateinit var notesInput: EditText
    private lateinit var visitDateInput: EditText
    private lateinit var Save: Button
    private lateinit var Update: Button
    private lateinit var Delete: Button
    private lateinit var petRecyclerView: RecyclerView

    private var selectedPetId: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val db = Firebase.database
        val petRef = db.getReference("pets")
        petNameInput = findViewById(R.id.petNameInput)
        breedInput = findViewById(R.id.breedInput)
        petAgeInput = findViewById(R.id.petAgeInput)
        notesInput = findViewById(R.id.notesInput)
        visitDateInput = findViewById(R.id.visitDateInput)
        Save = findViewById(R.id.Save)
        Update = findViewById(R.id.Update)
        Delete = findViewById(R.id.Delete)
        petRecyclerView = findViewById(R.id.petRecyclerView)
        var selectedPetId: String? = null

        Save.setOnClickListener {
            val petName = petNameInput.text.toString().trim()
            val breed = breedInput.text.toString().trim()
            val age = petAgeInput.text.toString().trim()
            val notes = notesInput.text.toString().trim()
            val lastVisit = visitDateInput.text.toString().trim()

            val pet = Pet(petName, breed, age, notes, lastVisit)

            val petId = petRef.push().key ?: return@setOnClickListener

            petRef.child(petId).setValue(pet)
                .addOnSuccessListener {
                    Toast.makeText(this, "Pet saved!", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to save pet", Toast.LENGTH_SHORT).show()
                }
            petNameInput.setText("")
            breedInput.setText("")
            petAgeInput.setText("")
            notesInput.setText("")
            visitDateInput.setText("")
        }

        Update.setOnClickListener {
            val updatedPet = Pet(
                name = petNameInput.text.toString().trim(),
                breed = breedInput.text.toString().trim(),
                age = petAgeInput.text.toString().trim(),
                notes = notesInput.text.toString().trim(),
                lastVisit = visitDateInput.text.toString().trim(),
                id = selectedPetId ?: ""
            )

            selectedPetId?.let {
                petRef.child(it).setValue(updatedPet)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Pet updated!", Toast.LENGTH_SHORT).show()
                        Update.visibility = View.GONE
                        Save.visibility = View.VISIBLE
                        clearForm()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show()
                    }
            }
        }

        Delete.setOnClickListener {
            selectedPetId?.let {
                petRef.child(it).removeValue()
                    .addOnSuccessListener {
                        Toast.makeText(this, "Pet deleted!", Toast.LENGTH_SHORT).show()
                        clearForm()
                        Save.visibility = View.VISIBLE
                        Update.visibility = View.GONE
                        Delete.visibility = View.GONE
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                    }
            } ?: Toast.makeText(this, "No pet selected to delete", Toast.LENGTH_SHORT).show()
        }

        val petList = mutableListOf<Pet>()
        val adapter = PetAdapter(petList) { selectedPet ->
            // Fill form fields
            petNameInput.setText(selectedPet.name)
            breedInput.setText(selectedPet.breed)
            petAgeInput.setText(selectedPet.age)
            notesInput.setText(selectedPet.notes)
            visitDateInput.setText(selectedPet.lastVisit)

            selectedPetId = selectedPet.id
            Update.visibility = View.VISIBLE
            Save.visibility = View.GONE
            Delete.visibility = View.VISIBLE
        }

        val petRecyclerView: RecyclerView = findViewById(R.id.petRecyclerView)
        petRecyclerView.layoutManager = LinearLayoutManager(this)
        petRecyclerView.adapter = adapter

        petRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                petList.clear()
                for (data in snapshot.children) {
                    val pet = data.getValue(Pet::class.java)
                    if (pet != null) {
                        val petWithId = pet.copy(id = data.key!!)
                        petList.add(petWithId)
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed to load pets", Toast.LENGTH_SHORT).show()
            }
        })


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

    }
    private fun clearForm() {
        petNameInput.setText("")
        breedInput.setText("")
        petAgeInput.setText("")
        notesInput.setText("")
        visitDateInput.setText("")
        Update.visibility = View.GONE
        Save.visibility = View.VISIBLE
        Delete.visibility = View.GONE
    }


}