package com.example.pethealthtracker

data class Pet(
    val name: String = "",
    val breed: String = "",
    val age: String = "",
    val notes: String = "",
    val lastVisit: String = "",
    val id: String = ""
)