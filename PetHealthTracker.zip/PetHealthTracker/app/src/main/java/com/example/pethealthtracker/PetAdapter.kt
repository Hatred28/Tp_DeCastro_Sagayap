package com.example.pethealthtracker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PetAdapter(private val petList: List<Pet>,
                 private val onItemClick: (Pet) -> Unit
) : RecyclerView.Adapter<PetAdapter.PetViewHolder>() {

    class PetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val petName: TextView = itemView.findViewById(R.id.tvPetName)
        val breed: TextView = itemView.findViewById(R.id.tvBreed)
        val age: TextView = itemView.findViewById(R.id.tvAge)
        val notes: TextView = itemView.findViewById(R.id.tvNotes)
        val lastVisit: TextView = itemView.findViewById(R.id.tvLastVisit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PetViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pet, parent, false)
        return PetViewHolder(view)
    }

    override fun onBindViewHolder(holder: PetViewHolder, position: Int) {
        val pet = petList[position]
        holder.petName.text = "Name: ${pet.name}"
        holder.breed.text = "Breed: ${pet.breed}"
        holder.age.text = "Age: ${pet.age}"
        holder.notes.text = "Notes: ${pet.notes}"
        holder.lastVisit.text = "Last Visit: ${pet.lastVisit}"

        holder.itemView.setOnClickListener {
            onItemClick(pet)
        }
    }

    override fun getItemCount(): Int = petList.size
}
